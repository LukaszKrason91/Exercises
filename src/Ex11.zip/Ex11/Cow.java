package Ex11;

import Ex11.Animal;

public class Cow implements Animal {

    @Override
    public void makeSound() {
        System.out.println("Muuuuuuu");
    }
}
