package Ex11;

public interface Animal {
    public void makeSound();
}
